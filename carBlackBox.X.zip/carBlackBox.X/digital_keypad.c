/* 
 * File:   digital_keypad.c
 * Author: Pranav Ahuja
 * DESC: 
 * Created on October 30, 2023, 10:34 PM
 */

#include <xc.h>

#include "digital_keypad.h"

void init_digital_keypad()
{
    DK_KEYPAD_PORTY_DDR = DK_KEYPAD_PORTY_DDR | DK_INPUT_LINES;
}

unsigned char read_digital_keypad(unsigned char mode)
{
    static unsigned char once = 1;
    if(mode == DK_LEVEL_MODE)
    {
        if(DK_KEYPAD_PORT & DK_INPUT_LINES != DK_ALL_RELEASED)
        {
            return DK_KEYPAD_PORT & DK_INPUT_LINES;
        }
    }
    else if(mode == DK_STATE_MODE)
    {
        if(((DK_KEYPAD_PORT & DK_INPUT_LINES) != DK_ALL_RELEASED) && once)
        {
            once = 0;
            return DK_KEYPAD_PORT & DK_INPUT_LINES;
        }
        else if((DK_KEYPAD_PORT & DK_INPUT_LINES) == DK_ALL_RELEASED)
        {
            once = 1;
        }
    }    
    return DK_ALL_RELEASED;
}