/* 
 * File:   lcd_screen.c
 * Author: Pranav Ahuja
 * DESC: 
 * Created on November 1, 2023, 9:53 PM
 */

#include "main.h"
extern unsigned char to_print[3];
extern unsigned char time[9];
extern unsigned char password_address;
extern unsigned char screens_flag;
extern unsigned char sys_pass[];

void default_screen(unsigned char event[3], unsigned short speed)
{    
    clcd_print("TIME     EVT  SP", LINE1(0)); 
    get_time();
    clcd_print(time, LINE2(0));
    
    clcd_print(event, LINE2(9));
    
    //adc to char
    if(!strcmp(event, "ON"))
        speed = 0;
    to_print[0] = (speed / 10) + '0';
    to_print[1] = (speed % 10) + '0';
    to_print[2] = '\0';
    clcd_print(to_print, LINE2(14));
}

void login_screen(unsigned char reset_flag, unsigned char key)
{
    static char attempt = 3, i = 0;
    char user_pss[PASSWORD_LENGTH+1];
    
    if(reset_flag == RESET_PASSWORD)
    {
        attempt = 3;
        user_pss[0] = '\0';
        user_pss[1] = '\0';
        user_pss[2] = '\0';
        user_pss[3] = '\0';
        
        i = 0;
        key = 0xFF;  
    }
    else {
        if(key == DKS4 && i < 4)
            {
                user_pss[i] = '1';            
                clcd_putch('*', LINE2(6 + i));
                i++;
            }
        else if(key == DKS5 && i < 4)
            {
                user_pss[i] = '0';
                clcd_putch('*', LINE2(6 + i));
                i++;
            }

        if(i == 4)
        {               
            user_pss[i] = '\0';
//            for(int k = 0; k < PASSWORD_LENGTH; k++)
//            {
//                password_address += k;
//                sys_pss[k] = random_read_at24c04(password_address);                
//            }
//            sys_pss[i] = '\0';
            if(attempt > 0)
            {
                if(!strcmp(user_pss, sys_pass))
                {
                    screens_flag = MENU_SCREEN;   
                    clcd_specific_instruction(CLCD_CLEAR_DISPLAY);
                    clcd_specific_instruction(CLCD_DISPLAY_ON_CURSOR_OFF);
                }
                else{
                    
                    attempt--;
                    i = 0;
                    clcd_print("WRONG Password", LINE2(0));
                    for(long int i = 100000; i--; );
                    clcd_print("                ", LINE2(0));                    
                    clcd_goto_pos(CLCD_POS_FOR_PASSWORD);
                    clcd_specific_instruction(CLCD_DISPLAY_ON_CURSOR_BLINKING); 
                }
            }
            if(attempt == 0)
            {
                clcd_print("Failed", LINE2(5));
                
            }
        }
        
    }
    
        
    
}
void menu_screen()
{
    clcd_print("      MENU      ", LINE1(0));
}

void get_time()
{
    unsigned char clock_reg[3];
        
    clock_reg[0] = i2c_rtc_read(HR_REG);
    clock_reg[1] = i2c_rtc_read(MIN_REG);
    clock_reg[2] = i2c_rtc_read(SEC_REG);
    
    time[0] = ((clock_reg[0] >> 4) & 0x03) + '0';
    time[1] = (clock_reg[0] & 0x0F) + '0';
    time[2] = ':';
    
    time[3] = ((clock_reg[1] >> 4) & 0x07) + '0';
    time[4] = (clock_reg[1] & 0x0F) + '0';
    time[5] = ':';
    
    time[6] = ((clock_reg[2] >> 4) & 0x07) + '0';
    time[7] = (clock_reg[2] & 0x0F) + '0';
    time[8] = '\0';        
}