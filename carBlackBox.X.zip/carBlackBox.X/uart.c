/* 
 * File:   uart.c
 * Author: Pranav Ahuja
 * DESC: 
 * Created on November 3, 2023, 9:12 PM
 */

#include "main.h"

void main(void) {

}
