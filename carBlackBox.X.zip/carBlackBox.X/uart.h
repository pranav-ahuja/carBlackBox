/* 
 * File:   uart.h
 * Author: Pranav Ahuja
 *
 * Created on November 3, 2023, 9:12 PM
 */

#ifndef UART_H
#define	UART_H

#include <xc.h>

#define UART_FOSC               20000000



#endif	/* UART_H */

