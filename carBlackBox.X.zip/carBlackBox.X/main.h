/* 
 * File:   main.h
 * Author: Rakesh Ahuja
 *
 * Created on October 30, 2023, 4:52 PM
 */
#include<xc.h>

#ifndef MAIN_H
#define	MAIN_H

#include <xc.h>
#include <string.h>
#include "adc.h"
#include "clcd.h"
#include "digital_keypad.h"
#include "i2c.h"
#include "rtc_ds1307.h"
#include "AT24C04.h"
#include "uart.h"


#define COLLISION                   'C'
#define PASSWORD_LENGTH             4

#define DASHBOARD_SCREEN            1
#define LOGIN_SCREEN                2
#define MENU_SCREEN                 3

#define ADC_TO_CLCD_STR             1
#define CLCD_STR                    2
#define GEAR_TO_CLCD                3

#define RESET_PASSWORD              1
#define RESET_NOTHING               0

void adc_to_speed(unsigned short adc_val);
void val_to_clcd(unsigned char peripheral);
void eeprom_log_data(unsigned char *event, unsigned char speed);
void eeprom_data_to_memory();
void default_screen(unsigned char event[3], unsigned short speed);

void login_screen(unsigned char reset_flag, unsigned char key);
void menu_screen();
void get_time();

#endif	/* MAIN_H */

